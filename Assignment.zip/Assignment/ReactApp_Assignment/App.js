import React from "react";
import "./styles.css";

export default class ShowHideCheckBoxContent extends React.Component {
  constructor(props) {
  	super(props);
    this.state = { checked: false };
    this.showHideTextContents = this.showHideTextContents.bind(this);
  }
  
  showHideTextContents() {
  	this.setState({
    	checked: !this.state.checked
    })
  }
  
  render() {
    const showHideContents = this.state.checked 
    	? <div> {'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'} </div>
      : null;
    
    return <div>
    	<div>
        <input type="checkbox" checked={ this.state.checked } onChange={ this.showHideTextContents } />
        <label>{'Show/Hide data'}</label>
      </div>
       { showHideContents }
    </div>;
  }
}



